import React from 'react'

function Offer() {
  return (
    <div>Offer</div>
  )
}

export default Offer